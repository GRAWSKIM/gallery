package com.std.sec.user;

public interface UsersService{	
	public boolean insertUser(String id, String pw) throws Exception;

}
